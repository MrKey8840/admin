<?php include "connect.php"; session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Главная</title>
	<link rel="stylesheet" type="text/css" href="/styles/default.css">
	<link rel="stylesheet" type="text/css" href="/styles/index.css">
	<link rel="icon" type="image/png" href="/favicon.png">
</head>
<body>

<div id="body">

<?php include "private/header.php"; ?>

<div id="content">
	<?php $content = mysqli_query($mysql, "SELECT * FROM content ORDER BY orderlines");
	foreach ($content as $key => $value) { ?>
		<div class="link_article">
			<h4><a href="<?php echo 'page?id='.$value['id'] ?>"><?php echo $value['header']; ?></a></h4>
			<p><?php echo $value['description']; ?></p>
		</div>
	<?php } ?>
</div>

<?php include "private/basement.php"; ?>

</div>

</body>
</html>