<?php

echo $_SESSION['user_name'];

?>