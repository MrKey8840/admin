<?php

include $_SERVER['DOCUMENT_ROOT']."/connect.php";
session_start();

$login = mysqli_real_escape_string($mysql, $_POST['login']);
$password = sha1(mysqli_real_escape_string($mysql, $_POST['password']));
$role = mysqli_fetch_array(mysqli_query($mysql, "SELECT role FROM users WHERE login='$login' AND password='$password'"));
if(empty($role)){
	echo "Неверные логин или пароль!";
	exit;
}
$_SESSION['user_name'] = $login;
$_SESSION['user_role'] = $role[0];
echo "Успех";

?>