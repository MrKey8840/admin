<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/styles/default.css">
	<link rel="stylesheet" type="text/css" href="/styles/login.css">
	<link rel="icon" type="image/png" href="/favicon.png">
	<script type="text/javascript" src="/scripts/jquery.js"></script>
	<script type="text/javascript" src="/scripts/login.js"></script>
	<title>Авторизация</title>
</head>
<body>
<div id="body">
	
<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
include $_SERVER['DOCUMENT_ROOT']."/private/header.php";
?>

<div id="form">
	<h1>Вход</h1>
	<p>Логин:</p>
	<input id="login_input">
	<p>Пароль:</p>
	<input type="password" id="password_input">
	<button id="login_button">Войти</button>
</div>

<?php
include $_SERVER['DOCUMENT_ROOT']."/private/basement.php";
?>

</div>
</body>
</html>