<div id="basement">
	<link rel="stylesheet" type="text/css" href="../styles/basement.css">
	<p>
		<?php echo mysqli_fetch_array(mysqli_query($mysql, "SELECT phone FROM page WHERE id = 1"))[0]; ?>
		<br>
		<?php echo mysqli_fetch_array(mysqli_query($mysql, "SELECT email FROM page WHERE id = 1"))[0]; ?>
		<br>
		<?php if (isset($_SESSION['user_role']) and $_SESSION['user_role'] == 'admin') { ?>
			<a href="/admin" target="_blank">К админке</a>
		<?php } ?>
	</p>
</div>