<?php session_start(); ?>
<div id="header">
	<link rel="stylesheet" type="text/css" href="/styles/header.css">
	<script type="text/javascript" src="/scripts/jquery.js"></script>
	<script type="text/javascript" src="/scripts/header.js"></script>

	<div>
		<?php
			$mainpage = ($_SERVER['HTTPS'] ? "https" : "http")."://".$_SERVER['HTTP_HOST']."/";
			$title = mysqli_fetch_array(mysqli_query($mysql, "SELECT header FROM page WHERE id = 1"))[0];
		?>
		<a href="<? echo $mainpage ?>"><?php echo $title; ?></a>
	</div>

	<div>
	<?php
	$links = mysqli_query($mysql, "SELECT * FROM menu");
	foreach ($links as $key => $value) { ?>
		<a href="<?php echo $value['link']; ?>"><?php echo $value['text']; ?></a>
	<?php } ?>
	</div>

	<div id="account">
		<?php if(!isset($_SESSION['user_name'])) { ?>
			<button id="login">Вход</button><button id="register">Регистрация</button>
		<?php }
		else {
			$user = $_SESSION['user_name']; ?>
			<p><? if($_SESSION['user_role'] == "admin"){ ?>
				<a target="_black" href="/admin/"><?php echo $user; ?></a> 
			<?php } 
			else { echo $user; } ?></p> <button id="exit">Выход</button>
		<?php } ?>
	</div>
</div>