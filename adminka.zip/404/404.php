<?php include $_SERVER['DOCUMENT_ROOT']."/connect.php"; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>404</title>
	<link rel="stylesheet" type="text/css" href="/styles/default.css">
	<link rel="icon" type="image/png" href="/favicon.png">
</head>
<body>
<div id="body">

<?php include $_SERVER['DOCUMENT_ROOT']."/private/header.php"; ?>

<h1 align="center">404: Такой страницы нет</h1>

<?php include $_SERVER['DOCUMENT_ROOT']."/private/basement.php"; ?>

</div>
</body>
</html>