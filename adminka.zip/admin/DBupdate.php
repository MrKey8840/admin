<?php

include "../connect.php";

session_start();

if(isset($_POST['change_content'])){
	$id = $_POST['id'];
	$header = $_POST['header'];
	$text = nl2br($_POST['text']);
	$description = $_POST['description'];
	mysqli_query($mysql, "UPDATE content SET header='$header' WHERE id = $id");
	mysqli_query($mysql, "UPDATE content SET text='$text' WHERE id = $id");
	mysqli_query($mysql, "UPDATE content SET description='$description' WHERE id = $id");
}
if(isset($_POST['change_header'])){
	$header = $_POST['header'];
	mysqli_query($mysql, "UPDATE page SET header='$header' WHERE id = 1");
}
if(isset($_POST['change_basement'])){
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	mysqli_query($mysql, "UPDATE page SET phone='$phone' WHERE id = 1");
	mysqli_query($mysql, "UPDATE page SET email='$email' WHERE id = 1");
}
if(isset($_POST['change_menu'])){
	$text1 = $_POST['text1'];
	$text2 = $_POST['text2'];
	$text3 = $_POST['text3'];
	$link1 = $_POST['link1'];
	$link2 = $_POST['link2'];
	$link3 = $_POST['link3'];
	mysqli_query($mysql, "UPDATE menu SET text='$text1', link='$link1' WHERE id = 1");
	mysqli_query($mysql, "UPDATE menu SET text='$text2', link='$link2' WHERE id = 2");
	mysqli_query($mysql, "UPDATE menu SET text='$text3', link='$link3' WHERE id = 3");
}
if(isset($_POST['add_content'])){
	$header = $_POST['header'];
	$description = $_POST['description'];
	$text = nl2br($_POST['text']);
	$max = intval(mysqli_fetch_array(mysqli_query($mysql, "SELECT MAX(orderlines) FROM content"))) + 1;
	$query = "INSERT INTO content(header, description, text, orderlines) VAlUES ('$header', '$description', '$text', $max)";
	mysqli_query($mysql, $query);
}

header('Location: ../admin');
exit;
?>