<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
session_start();
$_SESSION['admin_page'] = "header_page";

$header = mysqli_fetch_array(mysqli_query($mysql, "SELECT header FROM page WHERE id = 1"))[0];
?>
<h1>Заголовок</h1>
<input id="header" placeholder='Заголовок' value=<? echo $header; ?>><br>
<button id="save_header">Сохранить</button>