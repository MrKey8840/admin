<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
session_start();
$text1 = mysqli_fetch_array(mysqli_query($mysql, "SELECT text FROM menu WHERE id = 1 "))[0];
$text2 = mysqli_fetch_array(mysqli_query($mysql, "SELECT text FROM menu WHERE id = 2 "))[0];
$text3 = mysqli_fetch_array(mysqli_query($mysql, "SELECT text FROM menu WHERE id = 3 "))[0];
$link1 = mysqli_fetch_array(mysqli_query($mysql, "SELECT link FROM menu WHERE id = 1 "))[0];
$link2 = mysqli_fetch_array(mysqli_query($mysql, "SELECT link FROM menu WHERE id = 2 "))[0];
$link3 = mysqli_fetch_array(mysqli_query($mysql, "SELECT link FROM menu WHERE id = 3 "))[0];
$_SESSION['admin_page'] = "menu_page";
?>
<h1>Меню</h1>
<form method='POST' action='/admin/DBupdate.php'>
<input name='link1' placeholder='Ссылка 1' value=<?php echo $link1; ?>><input name='text1' placeholder='Текст ссылки 1' value=<?php echo $text1; ?>><br>
<input name='link2' placeholder='Ссылка 2' value=<?php echo $link2; ?>><input name='text2' placeholder='Текст ссылки 2' value=<?php echo $text2; ?>><br>
<input name='link3' placeholder='Ссылка 3' value=<?php echo $link3; ?>><input name='text3' placeholder='Текст ссылки 3' value=<?php echo $text3; ?>><br>
<input type='submit' name='change_menu' value='Сохранить'>
</form>