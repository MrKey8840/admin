<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
session_start();
$_SESSION['admin_page'] = "content_page";
?>
<script type="text/javascript" src="/scripts/drag.js"></script>
<h1>Контент</h1>
<button id="add_content">Добавить</button>
<ul class="sortable-list">
<?php $content = mysqli_query($mysql, "SELECT * FROM content ORDER BY orderlines");
foreach ($content as $key => $value) { ?>
	<li class="item" draggable="true">
	<div class="content_div" id="<?php echo $value['id'] ?>">
		<h4><?php echo $value['header'] ?></h4>
		<button class="change_content">Изменить</button>
		<button class="delete_content">Удалить</button>
	</div>
	</li>
<?php } ?>
</ul>
<button id="save_order">Сохранить</button>