<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
session_start();
$phone = mysqli_fetch_array(mysqli_query($mysql, "SELECT phone FROM page WHERE id = 1 "))[0];
$email = mysqli_fetch_array(mysqli_query($mysql, "SELECT email FROM page WHERE id = 1 "))[0];
$_SESSION['admin_page'] = "basement_page";
?>
<h1>Подвал</h1>
<form  method='POST' action='DBupdate.php'>
<input name='phone' placeholder='Телефон' value=<?php echo $phone; ?>><br>
<input name='email' placeholder='Почта' value=<?php echo $email; ?>><br>
<input type='submit' name='change_basement' value='Сохранить'></form>