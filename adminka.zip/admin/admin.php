<?php
session_start();
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
$main_page = ($_SERVER['HTTPS'] ? "https" : "http")."://".$_SERVER['HTTP_HOST']."/";
if(!isset($_SESSION['user_name'])){
	header("Location: ".$main_page);
	exit;
}
if($_SESSION['user_role'] != "admin"){
	header("Location: ".$main_page);
	exit;
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/styles/admin.css">
	<link rel="icon" type="image/png" href="/favicon.png">
	<script type="text/javascript" src="/scripts/jquery.js"></script>
	<script type="text/javascript" src="/scripts/admin.js"></script>
	<title>Админка</title>
</head>
<body>
<div id="admin">

<div id="admin_menu">
	<button class="admin_menu_button" id="content_page">Контент</button>
	<button class="admin_menu_button" id="header_page">Заголовок</button>
	<button class="admin_menu_button" id="menu_page">Ссылки</button>
	<button class="admin_menu_button" id="basement_page">Подвал</button>
	<button class="admin_menu_button" id="exit">Выход</button>
</div>

<div id="admin_page">
	<?php
	if(!isset($_SESSION['admin_page'])){ $_SESSION['admin_page'] = "content_page";}
	include $_SERVER['DOCUMENT_ROOT']."/admin/pages/".$_SESSION['admin_page'].".php";
	?>
</div>

</div>
</body>
</html>