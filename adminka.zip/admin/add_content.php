<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="/favicon.png">
	<script type="text/javascript" src="/scripts/jquery.js"></script>
	<script type="text/javascript" src="/scripts/add_content.js"></script>
	<title>Добавить</title>
</head>
<body>

<h1>Добавить</h1>
<button id="bold"><b>Ж</b></button><button id="italic"><i>К</i></button><button id="underline"><u>Ч</u></button>
<button class="color" id="red" style='background-color: red; color: red;'>К</button>
<button class="color" id="blue" style='background-color: blue; color: blue;'>К</button>
<button class="color" id="purple" style='background-color: purple; color: purple;'>К</button>
<button class="color" id="green" style='background-color: green; color: green;'>К</button>
<button class="color" id="brown" style='background-color: brown; color: brown;'>К</button><br>
<form method="POST" action="DBupdate.php">
	<input name="header" placeholder="Заголовок"><br>
	<input name="description" placeholder="Описание"><br>
	<textarea name="text" placeholder="Текст" id="textarea" style="width: 600px; height: 400px;"></textarea>
	<br>
	<input type="submit" name="add_content" value="Добавить">
</form>

</body>
</html>