<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
foreach ($_POST as $key => $value) {
	mysqli_query($mysql, "UPDATE content SET orderlines='$value' WHERE id='$key'");
}
?>