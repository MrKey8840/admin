<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
mysqli_query($mysql, "DELETE FROM content WHERE id=$_POST[id]");
?>