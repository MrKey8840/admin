<?php

$mysql = mysqli_connect('MySQL-8.2', 'root', '', 'ter');

?>