-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: MySQL-8.2
-- Время создания: Мар 09 2025 г., 16:11
-- Версия сервера: 8.2.0
-- Версия PHP: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ter`
--

-- --------------------------------------------------------

--
-- Структура таблицы `coments`
--

CREATE TABLE `coments` (
  `id` int NOT NULL,
  `content` int NOT NULL,
  `user` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `coments`
--

INSERT INTO `coments` (`id`, `content`, `user`, `text`) VALUES
(14, 24, 'admin', 'Комментарий'),
(15, 24, 'MrKey8840', '1234567890-0');

-- --------------------------------------------------------

--
-- Структура таблицы `content`
--

CREATE TABLE `content` (
  `id` int NOT NULL,
  `header` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderlines` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `content`
--

INSERT INTO `content` (`id`, `header`, `description`, `text`, `orderlines`) VALUES
(24, 'Статья', 'Жанр', 'Статья́ — жанр журналистики, в котором автор ставит задачу проанализировать общественные ситуации, процессы, явления, прежде всего с точки зрения закономерностей, лежащих в их основе. В статье автор рассматривает отдельные ситуации как часть более широкого явления. Автор аргументированно пишет о своей точке зрения.<br />\r\n<br />\r\nВ статье выражается развернутая обстоятельная аргументированная концепция автора или редакции по поводу актуальной социологической проблемы. Также в статье журналист обязательно должен интерпретировать факты (это могут быть цифры, дополнительная информация, которая будет правильно расставлять акценты и ярко раскрывать суть вопроса).<br />\r\n<br />\r\nОтличительным аспектом статьи является её готовность. Если подготавливаемый материал так и не был опубликован (не вышел в тираж, не получил распространения), то такой труд относить к статье некорректно. Скорее всего данную работу можно назвать черновиком или заготовкой. Поэтому целью любой статьи является распространение содержащейся в ней информации.<br />\r\n<br />\r\nВ современной журналистике выделяют пять видов статей:<br />\r\n<br />\r\n<b>Передовая статья</b><br />\r\nПередовая статья выражает точку зрения редакции по самому актуальному вопросу в данный момент. Передовая статья помогает правильно ориентироваться в проблемах общественной жизни, реагирует на самые актуальные вопросы.<br />\r\n<br />\r\nОсновные требования: актуальность темы, глубокое раскрытие и обоснование выдвигаемых задач, конкретность и лаконичность обобщений, выводов, аргументов.<br />\r\n<br />\r\nПередовые статьи могут быть:<br />\r\n<br />\r\nобщеполитическими — публикуются в связи с знаменательными датами, событиями;<br />\r\nпропагандистскими — раскрывают перспективы созидания, осуществление тех или иных идей;<br />\r\nоперативными — отражают наиболее актуальные на данный момент политические и хозяйственные задачи.<br />\r\n<br />\r\n<b>Научная статья</b><br />\r\nНа примерах конкретных ситуаций дается научно-теоретическое объяснение текущих событий. В таких статьях анализируются теоретические аспекты экономики, политики, литературы и искусства.<br />\r\n<br />\r\n<b>Информационная статья</b><br />\r\nИнформационно-повествовательная — материал располагается в последовательности, которая, как правило, соответствует их временному или пространственному развитию, свершению.<br />\r\nИнформационно-описательная — публикуются либо в связке с информационно-повествовательной либо отдельно от неё. В статье данного вида, информация излагается таким образом, чтобы у читателя составилось представление о предмете описания в целом, а также о его составных частях, отдельных свойствах и признаках.<br />\r\n<br />\r\n<b>Общеисследовательская статья</b><br />\r\nК этой группе относятся публикации, в которых анализируются общезначимые, широкие вопросы. Например, автор такой статьи может вести речь о направлениях политического или экономического развития страны или рассуждать об уровне нравственности, существующем на сегодняшний день в обществе в целом, или о возможности союза церкви и государства, или о взаимоотношениях страны с зарубежными государствами, и т. п. Подобного рода публикации отличаются высоким уровнем обобщения, глобальностью мышления авторов. Цель общеисследовательской статьи заключается в изучении различных закономерностей, тенденций, перспектив развития современного общества. Общеисследовательская статья — жанр трудный в том смысле, что он требует не просто знания какой-то конкретной проблемы, но предполагает теоретическое объяснение её существования.<br />\r\n<br />\r\n<b>Практико-аналитическая статья</b><br />\r\nОна обращена прежде всего к актуальным практическим проблемам промышленности и жизни, сельского хозяйства, предпринимательства, культуры, науки, образования, бизнеса, финансов, и т. д. В этих статьях анализируются конкретные проблемы, события, действия, ситуации, связанные с практическими задачами, решаемыми в той или иной сфере деятельности, отрасли производства, и пр. Автор ставит перед собой цель, выявить причины ситуации, сложившейся в той или иной сфере производства, на ряде предприятий, в социальной сфере и т. д., оценить эти ситуации, определить тенденции их развития.			', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE `menu` (
  `id` int NOT NULL,
  `link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `menu`
--

INSERT INTO `menu` (`id`, `link`, `text`) VALUES
(1, 'https://vk.com', 'ВК'),
(2, 'https://ok.ru/', 'OK'),
(3, 'https://drive.google.com/drive/folders/1dC1ULLvPRgjowSX_2cMcYZXlDsNIeZrq?usp=drive_link', 'Google');

-- --------------------------------------------------------

--
-- Структура таблицы `page`
--

CREATE TABLE `page` (
  `id` int NOT NULL,
  `header` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `page`
--

INSERT INTO `page` (`id`, `header`, `content`, `phone`, `email`) VALUES
(1, 'Животные', 'вкепкереккер', '+784398980983', 'dfff@mail.ru'),
(2, '', 'кщукрпшгуркшгпр1234567890', '', ''),
(3, '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `login` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `role`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin'),
(9, 'MrKey8840', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'user'),
(10, 'nik', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'user');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `coments`
--
ALTER TABLE `coments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `coments`
--
ALTER TABLE `coments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT для таблицы `content`
--
ALTER TABLE `content`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT для таблицы `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `page`
--
ALTER TABLE `page`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
