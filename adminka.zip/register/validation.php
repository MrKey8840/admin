<?php

include $_SERVER['DOCUMENT_ROOT']."/connect.php";
session_start();

$login = $_POST['login'];
$password = $_POST['password'];
$repeat_password = $_POST['repeat_password'];

if($login == ""){
	echo "Логин не может быть пустым!";
	exit;
}
if(strlen($password) < 3){
	echo "Пароль должен быть минимум 3 символа!";
	exit;
}
if($password != $repeat_password){
	echo "Пароли не совпадают!";
	exit;
}
$user = mysqli_fetch_array(mysqli_query($mysql, "SELECT login FROM users WHERE login = '$login'"));
if($user != false){
	echo "Такой пользователь уже есть!";
	exit;
}

$login = mysqli_real_escape_string($mysql, $_POST['login']);
$password = sha1(mysqli_real_escape_string($mysql, $_POST['password']));
mysqli_query($mysql, "INSERT INTO users(login, password, role) VALUES ('$login', '$password', 'user')");
$_SESSION['user_name'] = $login;
$_SESSION['user_role'] = 'user';
echo "Успех";

?>