<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/styles/default.css">
	<link rel="stylesheet" type="text/css" href="/styles/register.css">
	<link rel="icon" type="image/png" href="/favicon.png">
	<script type="text/javascript" src="/scripts/jquery.js"></script>
	<script type="text/javascript" src="/scripts/register.js"></script>
	<title>Регистрация</title>
</head>
<body>
<div id="body">
	
<?php
include $_SERVER['DOCUMENT_ROOT']."/connect.php";
include $_SERVER['DOCUMENT_ROOT']."/private/header.php";
?>

<div id="form">
	<h1>Регистрация</h1>
	<p>Логин:</p>
	<input id="login_input">
	<p>Пароль:</p>
	<input type="password" id="password_input">
	<p>Повторите пароль:</p>
	<input type="password" id="repeat_password_input"><br>
	<button id="reg_button">Регистрация</button>
</div>

<?php
include $_SERVER['DOCUMENT_ROOT']."/private/basement.php";
?>

</div>
</body>
</html>