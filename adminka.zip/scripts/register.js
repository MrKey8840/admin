$(document).ready(function(){
	$("#reg_button").click(function(){

		let login = $("#login_input").val()
		let password = $("#password_input").val()
		let repeat_password = $("#repeat_password_input").val()

		$("#error").remove()
		
		$.ajax("validation.php", {
			method: "POST",
			data: {"login": login, "password": password, "repeat_password": repeat_password},
			success: function(data){
				if(data == "Успех"){
					window.location.assign("/")
				}
				else{
					$("h1").after(`<div id='error'>${data}</div>`)
				}
			}
		})
	})
})