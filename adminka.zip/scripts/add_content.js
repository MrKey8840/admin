$(document).ready(function(){
	$("#bold").click(function(){
		let textarea = document.getElementById('textarea')
		let start = textarea.selectionStart
		let end = textarea.selectionEnd
		let beforeText = textarea.value.substring(0, start)
		let text = textarea.value.substring(start, end)
		let afterText = textarea.value.substring(end, textarea.value.lenght)
		textarea.value = beforeText + "<b>" + text + "</b>" + afterText
	})
	$("#italic").click(function(){
		let textarea = document.getElementById('textarea')
		let start = textarea.selectionStart
		let end = textarea.selectionEnd
		let beforeText = textarea.value.substring(0, start)
		let text = textarea.value.substring(start, end)
		let afterText = textarea.value.substring(end, textarea.value.lenght)
		textarea.value = beforeText + "<i>" + text + "</i>" + afterText
	})
	$("#underline").click(function(){
		let textarea = document.getElementById('textarea')
		let start = textarea.selectionStart
		let end = textarea.selectionEnd
		let beforeText = textarea.value.substring(0, start)
		let text = textarea.value.substring(start, end)
		let afterText = textarea.value.substring(end, textarea.value.lenght)
		textarea.value = beforeText + "<u>" + text + "</u>" + afterText
	})
	$(".color").click(function(){
		let color = $(this).attr('id')
		let textarea = document.getElementById('textarea')
		let start = textarea.selectionStart
		let end = textarea.selectionEnd
		let beforeText = textarea.value.substring(0, start)
		let text = textarea.value.substring(start, end)
		let afterText = textarea.value.substring(end, textarea.value.lenght)
		textarea.value = beforeText + `<font color="${color}">` + text + `</font>` + afterText
	})
})