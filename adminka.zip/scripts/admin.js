$(document).ready(function() {
	$(".admin_menu_button").click(function(){
		let page = $(this).attr("id")
		if(page == "exit"){
			$.ajax("/private/exit.php", {
				success: function(){
					window.location.reload()
				}
			})
		}
		else{
			$.ajax(`pages/${page}.php`, {
				success: function(data){
					$("#admin_page").html(data)
				}
			})
		}
	})
})