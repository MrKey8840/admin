$(document).ready(function(){
	$("#send_comment").click(function(){
		let text = $("#comment_text").val()
		if(text == ""){
			alert("Комментарий не может быть пустым!")
			return
		}
		let url = $(location).attr('href')
		let content_id = url.match(/(?<=(id=))\d+/)[0]
		$.ajax("add_comment.php", {
			method: "POST",
			data: {"text": text, "content_id": content_id},
			dataType: "json",
			success: function(comment){
				$("#hr").after(`<div class='comment' id='${comment.id}'><div><b>${comment.user}</b><button class="delete">Удалить</button></div><p>${comment.text}</p></div>`)
				$("#comment_text").val("")
				$("#no_comments").remove()
			},
		})
	})
	$(document).on("click", ".delete", function(){
		let comment = $(this).parent().parent()
		let id = comment.attr("id")
		$.ajax("delete_comment.php", {
			method: "POST",
			data: {"comment_id": id},
			success: function(){
				comment.remove()
				if($(".comment").length == 0){
					$("#coments").append('<p id="no_comments">Комментариев нет</p>')
				}
			},
		})
	})
})