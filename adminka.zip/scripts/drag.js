$(document).ready(function() {
    const sortableList = document.querySelector(".sortable-list");
    const items = sortableList.querySelectorAll(".item");

    items.forEach(item => {
        item.addEventListener("dragstart", () => {
            // Adding dragging class to item after a delay
            setTimeout(() => item.classList.add("dragging"), 0);
        });
        // Removing dragging class from item on dragend event
            item.addEventListener("dragend", () => item.classList.remove("dragging"));
    });

    const initSortableList = (e) => {
        e.preventDefault();
        const draggingItem = document.querySelector(".dragging");
        // Getting all items except currently dragging and making array of them
        let siblings = [...sortableList.querySelectorAll(".item:not(.dragging)")];
    
        // Finding the sibling after which the dragging item should be placed
        let nextSibling = siblings.find(sibling => {
            return e.clientY <= sibling.offsetTop + sibling.offsetHeight / 2;
        });
    
        // Inserting the dragging item before the found sibling
        sortableList.insertBefore(draggingItem, nextSibling);
    }
    
    sortableList.addEventListener("dragover", initSortableList);
    sortableList.addEventListener("dragenter", e => e.preventDefault());

    $(document).on("click", "#save_order", function() {
        order = {}
        list = document.querySelector(".sortable-list").querySelectorAll(".item");
        for(var i = 0; i < list.length; i++){
            elem = list[i].childNodes[1].id;
            order[elem] = i
        }
        $.ajax("order_update.php", {
            method: "POST",
            data: {...order},
            success: function(){
                window.location.reload()
            }
        })
    })
    $("#add_content").click(function(){
        window.location.assign("/admin/add_content.php")
    })
    $(".change_content").click(function(){
        let id = $(this).parent().attr("id")
        window.location.assign(`/admin/change_content.php?id=${id}`)
    })
    $(".delete_content").click(function(){
        let id = $(this).parent().attr("id")
        $.ajax("delete_content.php", {
            method: "POST",
            data: {"id": id},
            success: function(data){
                window.location.reload()
            }
        })
    })
})