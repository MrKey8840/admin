$(document).ready(function(){
	$("#login").click(function(){
		window.location.assign("/login/")
	})
	$("#register").click(function(){
		window.location.assign("/register/")
	})
	$("#exit").click(function(){
		$.ajax("/private/exit.php", {
			success: function(){
				window.location.reload()
			}
		})
	})
})