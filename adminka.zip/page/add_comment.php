<?php

include $_SERVER['DOCUMENT_ROOT']."/connect.php";
session_start();

$user = $_SESSION['user_name'];
$text = strip_tags($_POST['text']);
$content_id = $_POST['content_id'];

$query = "INSERT INTO coments(content, user, text) VALUES ($content_id, '$user', '$text')";
mysqli_query($mysql, $query);
$comment_id = mysqli_insert_id($mysql);

$result = [];
$result["user"] = $user;
$result["id"] = $comment_id;
$result["text"] = $text;

echo json_encode($result);