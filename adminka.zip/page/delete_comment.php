<?php

include $_SERVER['DOCUMENT_ROOT']."/connect.php";

$comment_id = $_POST['comment_id'];

mysqli_query($mysql, "DELETE FROM coments WHERE id=$comment_id");

?>