<?php include "../connect.php"; session_start();
if(empty($_GET['id'])) { $_GET['id'] = 1; }
$content = mysqli_fetch_array(mysqli_query($mysql, "SELECT * FROM content WHERE id = ".$_GET['id'])); 
if(empty($content)) {include $_SERVER['DOCUMENT_ROOT']."/404/404.php"; exit; }
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="/styles/page.css">
	<link rel="stylesheet" type="text/css" href="/styles/default.css">
	<link rel="icon" type="image/png" href="/favicon.png">
	<script type="text/javascript" src="/scripts/jquery.js"></script>
	<script type="text/javascript" src="/scripts/page.js"></script>
	<title><?php echo $content['header']; ?></title>
</head>
<body>
<div id="body">

<?php include "$_SERVER[DOCUMENT_ROOT]/private/header.php"; ?>

<div id="article">
	<h2 align="center"><?php echo $content['header']; ?></h2>
	<p><?php echo $content['text'] ?></p>
</div>

<div id="coments">
	<h3>Коментарии</h3>
	<?php if(isset($_SESSION['user_name'])){ ?>
		<textarea placeholder="Коментарий" id="comment_text"></textarea><br>
		<button id="send_comment">Отправить</button>
	<?php } ?>
	<hr id="hr">
	<?php
		$coments = mysqli_query($mysql, "SELECT * FROM coments WHERE content = ".$_GET['id']." ORDER BY id DESC");
		if($coments->num_rows > 0){
			foreach ($coments as $key => $value) { ?>
				<div class="comment" id="<?php echo $value['id']; ?>">
					<div>
						<b><?php echo $value['user']; ?></b>
						<?php if(isset($_SESSION['user_name'])){
							if($_SESSION['user_name'] == $value['user'] or $_SESSION['user_role'] == "admin"){ ?>
								<button class="delete">Удалить</button>
							<?php }
						} ?>
					</div>
					<p><?php echo $value['text']; ?></p>
				</div>
			<?php }
		}
		else{
			echo '<p id="no_comments">Комментариев нет</p>';
		} ?>
</div>

<?php include $_SERVER['DOCUMENT_ROOT']."/private/basement.php"; ?>

</div>
</body>
</html>