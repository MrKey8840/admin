<div id="header">
	<link rel="stylesheet" type="text/css" href="../styles/header.css">
	<div><a href="http://ter"><?php echo mysqli_fetch_array(mysqli_query($mysql, "SELECT header FROM page WHERE id = 1"))[0]; ?></a></div>
	<div>
	<?php

	$links = mysqli_query($mysql, "SELECT * FROM menu");
	foreach ($links as $key => $value) { ?>
		<a href="<?php echo $value['link']; ?>"><?php echo $value['text']; ?></a>
	<?php } ?>
	</div>
	<div style="display: flex; align-items: center;">
		<?php if(empty($_SESSION['user_id'])) { ?>
			<form action="../autorisation"><button>Вход</button></form><form action="../registration"><button>Регистрация</button></form>
		<?php }
		else {
			$user = mysqli_fetch_array(mysqli_query($mysql, "SELECT login FROM users WHERE id = ".$_SESSION['user_id']))[0]; ?>
			<p><?php echo $user; ?></p><form action="../exit.php"><button>Выход</button></form>
		<?php } ?>
	</div>
</div>