<?php

include "../connect.php";

session_start();

if(isset($_POST['change_content'])){
	mysqli_query($mysql, "UPDATE content SET header='".$_POST['header']."' WHERE id = ".$_POST['id']);
	mysqli_query($mysql, "UPDATE content SET text='".nl2br($_POST['text'])."' WHERE id = ".$_POST['id']);
	mysqli_query($mysql, "UPDATE content SET description='".$_POST['description']."' WHERE id = ".$_POST['id']);
}
if(isset($_POST['change_order'])) {
	foreach ($_POST as $key => $value) {
		mysqli_query($mysql, "UPDATE content SET orderlines='$value' WHERE id='$key'");
	}
}
if(isset($_POST['header']) and empty($_POST['change_content']) and empty($_POST['add_content'])){
	mysqli_query($mysql, "UPDATE page SET header='".$_POST['header']."' WHERE id = 1");
}
if(isset($_POST['change_basement'])){
	mysqli_query($mysql, "UPDATE page SET phone='".$_POST['phone']."' WHERE id = 1");
	mysqli_query($mysql, "UPDATE page SET email='".$_POST['email']."' WHERE id = 1");
}
if(isset($_POST['change_menu'])){
	mysqli_query($mysql, "UPDATE menu SET text='".$_POST['text1']."', link='".$_POST['link1']."' WHERE id = 1");
	mysqli_query($mysql, "UPDATE menu SET text='".$_POST['text2']."', link='".$_POST['link2']."' WHERE id = 2");
	mysqli_query($mysql, "UPDATE menu SET text='".$_POST['text3']."', link='".$_POST['link3']."' WHERE id = 3");
}
if(isset($_POST['add_content'])){
	$max = intval(mysqli_fetch_array(mysqli_query($mysql, "SELECT MAX(orderlines) FROM content")));
	$max += 1;
	$query = "INSERT INTO content(header, description, text, orderlines) VAlUES ('".$_POST['header']."','".$_POST['description']."', '".nl2br($_POST['text'])."', $max)";
	mysqli_query($mysql, $query);
}

header('Location: ../admin');
exit;
?>