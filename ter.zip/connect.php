<?php

$mysql = mysqli_connect('localhost', 'root', 'root', 'ter');

?>