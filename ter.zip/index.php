<?php include "connect.php"; session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="">
	<link rel="stylesheet" type="text/css" href="styles/index.css">
</head>
<body>

<div style="min-height: 100%; border: 1px black solid;">

<?php include "private/header.php"; ?>

<div id="content">
	<?php $content = mysqli_query($mysql, "SELECT * FROM content ORDER BY orderlines");
	foreach ($content as $key => $value) { ?>
		<div class="link_article">
			<h4><a href="<?php echo 'page?id='.$value['id'] ?>"><?php echo $value['header']; ?></a></h4>
			<p><?php echo $value['description']; ?></p>
		</div>
	<?php } ?>
</div>

</div>

<?php include "private/basement.php"; ?>

</body>
</html>