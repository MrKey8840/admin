<?php include "../connect.php"; session_start(); ?>
<link rel="stylesheet" type="text/css" href="../styles/page.css">
<div style="min-height: 100%;">
	<?php include "../private/header.php"; ?>
	<h1 align="center">404: Такой страницы нет</h1>
</div>
<?php include "../private/basement.php"; ?>