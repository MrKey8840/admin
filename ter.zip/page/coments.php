<?php include "../connect.php"; session_start();
if(isset($_POST['Отправить'])){
	$user = mysqli_fetch_array(mysqli_query($mysql, "SELECT login FROM users WHERE id = ".$_SESSION['user_id']))[0];
	$text = strip_tags($_POST['text']);
	$content = (int)$_POST['id'];
	mysqli_query($mysql, "INSERT INTO coments(content, user, text) VALUES (".$content.", '".$user."', '".$text."')");
}
if(isset($_POST['delete'])){
	mysqli_query($mysql, "DELETE FROM coments WHERE id = ".$_POST['id']);
}
header('Location: '.$_SERVER['HTTP_REFERER']);
exit;