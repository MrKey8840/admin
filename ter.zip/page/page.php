<?php include "../connect.php"; session_start();
if(empty($_GET['id'])){ $_GET['id'] = 1; }
$content = mysqli_fetch_array(mysqli_query($mysql, "SELECT * FROM content WHERE id = ".$_GET['id'])); 
if(empty($content)){header('Location: ../404'); exit; } ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../styles/page.css">
</head>
<body>

<div style="min-height: 100%;">

<?php include "../private/header.php"; ?>

<div id="article">
	<h2 align="center"><?php echo $content['header']; ?></h2>
	<p><?php echo $content['text'] ?></p>
</div>

<div id="coments">
	<h3>Коментарии</h3>
	<?php if(isset($_SESSION['user_id'])){ ?>
		<form method="POST" action="coments.php">
			<input type="hidden" name="id" value=<?php echo $_GET['id'] ?>>
			<textarea placeholder="Коментарий" name="text"></textarea><br>
			<input type="submit" value="Отправить" name="Отправить">
		</form>
	<?php } ?>
	<hr>
	<?php
		$coments = mysqli_query($mysql, "SELECT * FROM coments WHERE content = ".$_GET['id']);
		if($coments->num_rows > 0){
			foreach ($coments as $key => $value) { ?>
				<div class="comment">
					<div>
						<b><?php echo $value['user']; ?></b>
						<?php if(isset($_SESSION['user_id'])){
							$user = mysqli_fetch_array(mysqli_query($mysql, "SELECT login FROM users WHERE id = ".$_SESSION['user_id']))[0];
							if($user == $value['user']){ ?>
								<form method="POST" action="coments.php"><input type="hidden" name="id" value=<?php echo $value['id']; ?>><input type="submit" name="delete" value="Удалить"></form>
							<?php }
						} ?>
					</div>
					<p><?php echo $value['text']; ?></p>
				</div>
			<?php }
		}
		else{
			echo "Комментариев нет";
		} ?>
</div>

</div>

<?php include "../private/basement.php"; ?>


</body>
</html>